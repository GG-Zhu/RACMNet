from sklearn.manifold import TSNE
from sklearn.datasets import load_iris,load_digits
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import os
import numpy as np

       

def plot_embedding_2d(X, y, title=None):
    """Plot an embedding X with the class label y colored by the domain d."""
    
   
    X_tsne = TSNE(n_components=2,random_state=33).fit_transform(X)
    X_pca = PCA(n_components=2).fit_transform(X)

    ckpt_dir="images"
    if not os.path.exists(ckpt_dir):
        os.makedirs(ckpt_dir)
    col=[]
    color=[0,4,5,3,8,9,1,7,6,2,17,16,14,12,13,11,18,15,17,10]
                                                                                                            
                                                                                                       
                                                                                                         
                                                                                                            
                                                                                                             
                                                                                                               
                                                                                                                  
                                                                                                               
                                                                                                                      
                                                                                                                       
                                                                                                                    
                                                                                                                      
                                                                                                                       
                                                                                                                      
                                                                                                                     
                                                                                                                        
                                                                                                                   
                        

    for i in range(0,len(y)):
        col.append(color[y[i]%20])
        
                                 
                                 
                                  
                                
                     
    plt.figure(figsize=(10, 5))
    plt.subplot(121)
                                                                                                     
    plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=col,cmap='tab20_r',label="t-SNE",marker='4',linewidth=1.1)
    plt.legend()
                      
                                                                                             
                                                                                       
                  
    plt.savefig('images/digits_tsne-pca', dpi=1000,format='eps')
    plt.show()
    
    



