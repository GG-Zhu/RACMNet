import argparse
import copy
import os
import sys

import torch
import torch.nn as nn


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CURRENT_DIR)

import model as model_lib
import resnet as resnet_lib


class PassthroughRRCM(nn.Module):
    def forward(self, x):
        mask = x.new_zeros((x.size(0), 1, x.size(2), x.size(3)))
        return x, mask


class PassthroughPGCM(nn.Module):
    def forward(self, x, s_mask=None):
        empty = x.new_zeros((x.size(0), 1, x.size(2), x.size(3)))
        return x, empty, empty


def disable_pretrained_downloads():
    """Build the architecture only; pretrained weights do not affect Params/FLOPs."""
    model_lib.resnet50 = lambda pretrained=True, **kwargs: resnet_lib.resnet50(
        pretrained=False, **kwargs
    )
    model_lib.resnet18 = lambda pretrained=True, **kwargs: resnet_lib.resnet18(
        pretrained=False, **kwargs
    )


def count_params(net):
    return sum(p.numel() for p in net.parameters())


class FlopCounter:
    def __init__(self):
        self.macs = 0
        self.handles = []

    def add_hooks(self, net):
        for module in net.modules():
            if isinstance(module, nn.Conv2d):
                self.handles.append(module.register_forward_hook(self.conv_hook))
            elif isinstance(module, nn.Linear):
                self.handles.append(module.register_forward_hook(self.linear_hook))
            elif isinstance(module, model_lib.Non_local):
                self.handles.append(module.register_forward_hook(self.nonlocal_hook))
            elif isinstance(module, model_lib.PrototypeGuidedContextualMiningModule):
                self.handles.append(module.register_forward_hook(self.pgcm_hook))

    def remove_hooks(self):
        for handle in self.handles:
            handle.remove()
        self.handles = []

    def conv_hook(self, module, inputs, output):
        x = inputs[0]
        batch_size = x.shape[0]
        out_channels = output.shape[1]
        out_h = output.shape[2]
        out_w = output.shape[3]
        kernel_h, kernel_w = module.kernel_size
        in_channels = module.in_channels
        groups = module.groups
        self.macs += (
            batch_size
            * out_channels
            * out_h
            * out_w
            * (in_channels // groups)
            * kernel_h
            * kernel_w
        )

    def linear_hook(self, module, inputs, output):
        x = inputs[0]
        batch_size = x.numel() // module.in_features
        self.macs += batch_size * module.in_features * module.out_features

    def nonlocal_hook(self, module, inputs, output):
        x = inputs[0]
        batch_size, _, height, width = x.shape
        locations = height * width
        channels = module.inter_channels
                                             
        self.macs += 2 * batch_size * locations * locations * channels

    def pgcm_hook(self, module, inputs, output):
        x = inputs[0]
        batch_size, channels, height, width = x.shape
        locations = height * width
        tokens = module.num_tokens
        mem_dim = module.mem_dim
                                                          
        self.macs += batch_size * locations * tokens * mem_dim
        self.macs += batch_size * locations * tokens * channels


def apply_variant(net, variant):
    if variant == "base":
        net.rrcm = PassthroughRRCM()
        net.pgcm = PassthroughPGCM()
    elif variant == "rrcm":
        net.pgcm = PassthroughPGCM()
    elif variant in {"pgcm", "racmnet"}:
        pass
    else:
        raise ValueError(f"Unknown variant: {variant}")
    return net


def profile_variant(base_net, variant, image_h, image_w, device):
    net = copy.deepcopy(base_net)
    net = apply_variant(net, variant).to(device).eval()

    inputs = (
        torch.randn(1, 3, image_h, image_w, device=device),
        torch.randn(1, 3, image_h, image_w, device=device),
    )

    counter = FlopCounter()
    counter.add_hooks(net)
    with torch.no_grad():
        net(inputs[0], inputs[1], modal=1)
    counter.remove_hooks()

    return count_params(net), counter.macs


def infer_layer3_shape(image_h, image_w):
                                                                 
    return 1024, image_h // 16, image_w // 16


def profile_module(module, inputs, device):
    module = module.to(device).eval()
    counter = FlopCounter()
    counter.add_hooks(module)
    with torch.no_grad():
        module(*inputs)
    counter.remove_hooks()
    return count_params(module), counter.macs


def profile_rrcm(image_h, image_w, device):
    channels, height, width = infer_layer3_shape(image_h, image_w)
    module = model_lib.ReliabilityRoutedCueMiningModule(channels)
    x = torch.randn(1, channels, height, width, device=device)
    return profile_module(module, (x,), device)


def profile_pgcm(image_h, image_w, device):
    channels, height, width = infer_layer3_shape(image_h, image_w)
    module = model_lib.PrototypeGuidedContextualMiningModule(
        in_channels=channels,
        mem_dim=128,
        num_tokens=128,
        comp_alpha=0.5,
    )
    x = torch.randn(1, channels, height, width, device=device)
    s_mask = torch.randn(1, 1, height, width, device=device)
    return profile_module(module, (x, s_mask), device)


def fmt_params(value):
    return f"{value / 1e6:.2f}M"


def fmt_flops(value):
    return f"{value / 1e9:.2f}G"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--class-num", type=int, default=395)
    parser.add_argument("--img-h", type=int, default=384)
    parser.add_argument("--img-w", type=int, default=192)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--arch", default="resnet50")
    parser.add_argument(
        "--mode",
        choices=["all", "network", "modules"],
        default="all",
        help="Print network totals, standalone module costs, or both.",
    )
    args = parser.parse_args()

    disable_pretrained_downloads()

    device = torch.device(args.device if torch.cuda.is_available() or args.device == "cpu" else "cpu")
    if args.mode in {"all", "network"}:
        base_net = model_lib.embed_net(
            args.class_num,
            no_local="on",
            gm_pool="on",
            arch=args.arch,
        )

        rows = [
            ("BASE", "base"),
            ("+RRCM", "rrcm"),
            ("+RRCM+PGCM", "pgcm"),
            ("RACMNet", "racmnet"),
        ]

        print("Network totals")
        print("| Method | Params | FLOPs | Note |")
        print("|---|---:|---:|---|")
        for name, variant in rows:
            params, flops = profile_variant(base_net, variant, args.img_h, args.img_w, device)
            note = ""
            if variant == "racmnet":
                note = "same inference cost as +RRCM+PGCM; CMCT is a training objective"
            print(f"| {name} | {fmt_params(params)} | {fmt_flops(flops)} | {note} |")

    if args.mode in {"all", "modules"}:
        channels, height, width = infer_layer3_shape(args.img_h, args.img_w)
        rows = [
            ("RRCM",) + profile_rrcm(args.img_h, args.img_w, device),
            ("PGCM",) + profile_pgcm(args.img_h, args.img_w, device),
        ]

        print()
        print(f"Standalone module costs, input feature shape: 1 x {channels} x {height} x {width}")
        print("| Module | Additional Params | Additional FLOPs |")
        print("|---|---:|---:|")
        for name, params, flops in rows:
            print(f"| {name} | {fmt_params(params)} | {fmt_flops(flops)} |")


if __name__ == "__main__":
    main()
