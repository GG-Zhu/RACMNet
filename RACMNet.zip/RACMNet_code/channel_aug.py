from __future__ import absolute_import

from torchvision.transforms import *
import torch
                      
import random
import math
                   
             

class ChannelAdap(object):
    """ Adaptive selects a channel or two channels.
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, probability = 0.5):
        self.probability = probability

       
    def __call__(self, img):

                                                     
                        

        idx = random.randint(0, 3)
        
        if idx ==0:
                                     
            img[1, :,:] = img[0,:,:]
            img[2, :,:] = img[0,:,:]
        elif idx ==1:
                                     
            img[0, :,:] = img[1,:,:]
            img[2, :,:] = img[1,:,:]
        elif idx ==2:
                                     
            img[0, :,:] = img[2,:,:]
            img[1, :,:] = img[2,:,:]
        else:
            img = img

        return img      
        
class ChannelAdapGray(object):
    """ Adaptive selects a channel or two channels.
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, probability = 0.5):
        self.probability = probability

       
    def __call__(self, img):

                                                     
                        

        idx = random.randint(0, 3)
        
        if idx ==0:
                                     
            img[1, :,:] = img[0,:,:]
            img[2, :,:] = img[0,:,:]
        elif idx ==1:
                                     
            img[0, :,:] = img[1,:,:]
            img[2, :,:] = img[1,:,:]
        elif idx ==2:
                                     
            img[0, :,:] = img[2,:,:]
            img[1, :,:] = img[2,:,:]
        else:
            if random.uniform(0, 1) > self.probability:
                            
                img = img
            else:
                tmp_img = 0.2989 * img[0,:,:] + 0.5870 * img[1,:,:] + 0.1140 * img[2,:,:]
                img[0,:,:] = tmp_img
                img[1,:,:] = tmp_img
                img[2,:,:] = tmp_img
        return img

class PCBRandomErasing(object):
    """ Randomly selects a rectangle region in an image and erases its pixels.
        'Random Erasing Data Augmentation' by Zhong et al.
        See https://arxiv.org/pdf/1708.04896.pdf
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, probability = 0.5, sl = 0.02, sh = 0.4, r1 = 0.3, mean=[0.4914, 0.4822, 0.4465]):
        
        self.probability = probability
        self.mean = mean
        self.sl = sl
        self.sh = sh
        self.r1 = r1
       
    def __call__(self, img):

        if random.uniform(0, 1) > 0.5:
            return img

        
                        
        area = img.size()[1] * img.size()[2]/6
        pcbnum=6
        pcb=int(img.size()[1]/pcbnum)
        if random.uniform(0, 1) > 0.99:
            for i in range(1,pcbnum):
                if random.uniform(0, 1) >0.5:
                    img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                else:
                    for attempt in range(100):
                        img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                        target_area=random.uniform(self.sl, self.sh) * area
                        aspect_ratio = random.uniform(self.r1, 1/self.r1)

                        h = int(round(math.sqrt(target_area * aspect_ratio)))
                        w = int(round(math.sqrt(target_area*6 / aspect_ratio)))

                        if w < img_pcb.size()[2] and h < img_pcb.size()[1]:
                            x1 = random.randint(0, img_pcb.size()[1] - h)
                            y1 = random.randint(0, img_pcb.size()[2] - w)
                            if img_pcb.size()[0] == 3:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                                img_pcb[1, x1:x1+h, y1:y1+w] = self.mean[1]
                                img_pcb[2, x1:x1+h, y1:y1+w] = self.mean[2]
                            else:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]

                            break
                        
                img[:,i*pcb:(i+1)*pcb,:]= img_pcb    
        elif random.uniform(0, 1) < 0.01:
            for i in range(0,pcbnum-1):
                if random.uniform(0, 1) >0.5:
                    img_pcb=img[:,i*pcb:(i+1)*pcb,:]

                else:

                    for attempt in range(100):
                        img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                        target_area=random.uniform(self.sl, self.sh) * area
                        aspect_ratio = random.uniform(self.r1, 1/self.r1)

                        h = int(round(math.sqrt(target_area * aspect_ratio)))
                        w = int(round(math.sqrt(target_area*6 / aspect_ratio)))

                        if w < img_pcb.size()[2] and h < img_pcb.size()[1]:
                            x1 = random.randint(0, img_pcb.size()[1] - h)
                            y1 = random.randint(0, img_pcb.size()[2] - w)
                            if img_pcb.size()[0] == 3:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                                img_pcb[1, x1:x1+h, y1:y1+w] = self.mean[1]
                                img_pcb[2, x1:x1+h, y1:y1+w] = self.mean[2]
                            else:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]

                            break
                        
                img[:,i*pcb:(i+1)*pcb,:]= img_pcb 
        elif random.uniform(0, 1) >= 0.49 and random.uniform(0, 1)<=0.51:
            for i in range(0,pcbnum):
                if random.uniform(0, 1) >0.5:
                    img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                 
                else:

                    for attempt in range(100):
                        img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                        target_area=random.uniform(self.sl, self.sh) * area
                        aspect_ratio = random.uniform(self.r1, 1/self.r1)

                        h = int(round(math.sqrt(target_area * aspect_ratio)))
                        w = int(round(math.sqrt(target_area*6 / aspect_ratio)))

                        if w < img_pcb.size()[2] and h < img_pcb.size()[1]:
                            x1 = random.randint(0, img_pcb.size()[1] - h)
                            y1 = random.randint(0, img_pcb.size()[2] - w)
                            if img_pcb.size()[0] == 3:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                                img_pcb[1, x1:x1+h, y1:y1+w] = self.mean[1]
                                img_pcb[2, x1:x1+h, y1:y1+w] = self.mean[2]
                            else:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]

                            break            
        else:   
            for i in range(1,pcbnum-1):
                if random.uniform(0, 1) >1:
                    img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                else:
                    for attempt in range(100):
                        img_pcb=img[:,i*pcb:(i+1)*pcb,:]
                        target_area=random.uniform(self.sl, self.sh) * area
                        aspect_ratio = random.uniform(self.r1, 1/self.r1)
                        h = int(round(math.sqrt(target_area/2 * aspect_ratio)))
                        w = int(round(math.sqrt(target_area*4 / aspect_ratio)))
                        if w < img_pcb.size()[2] and h < img_pcb.size()[1]:
                            x1 = random.randint(0, img_pcb.size()[1] - h)
                            y1 = random.randint(0, img_pcb.size()[2] - w)
                            if img_pcb.size()[0] == 3:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                                img_pcb[1, x1:x1+h, y1:y1+w] = self.mean[1]
                                img_pcb[2, x1:x1+h, y1:y1+w] = self.mean[2]
                            else:
                                img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                            break
                        
                img[:,i*pcb:(i+1)*pcb,:]= img_pcb 
                                                         
        return img
    
class ChannelExchange(object):
    """ Adaptive selects a channel or two channels.
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, gray = 2):
        self.gray = gray

    def __call__(self, img):
    
        idx = random.randint(0, self.gray)
        
        if idx ==0:
                                     
            img[1, :,:] = img[0,:,:]
            img[2, :,:] = img[0,:,:]
        elif idx ==1:
                                     
            img[0, :,:] = img[1,:,:]
            img[2, :,:] = img[1,:,:]
        elif idx ==2:
                                     
            img[0, :,:] = img[2,:,:]
            img[1, :,:] = img[2,:,:]
        else:
            tmp_img = 0.2989 * img[0,:,:] + 0.5870 * img[1,:,:] + 0.1140 * img[2,:,:]
            img[0,:,:] = tmp_img
            img[1,:,:] = tmp_img
            img[2,:,:] = tmp_img
        return img

class PCBChannelRandomErasing(object):
    """ Randomly selects a rectangle region in an image and erases its pixels.
        'Random Erasing Data Augmentation' by Zhong et al.
        See https://arxiv.org/pdf/1708.04896.pdf
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, probability = 0.5, sl = 0.02, sh = 0.4, r1 = 0.3, mean=[0.4914, 0.4822, 0.4465]):
        
        self.probability = probability
        self.mean = mean
        self.sl = sl
        self.sh = sh
        self.r1 = r1
       
    def __call__(self, img):

        if random.uniform(0, 1) > self.probability:
            return img
        img_pcb=torch.clone(img)
        pcbnum=6
        ph=img.size()[1]
        for attempt in range(100):
            area = img.size()[1] * img.size()[2]
       
            target_area = random.uniform(self.sl, self.sh) * area
            aspect_ratio = random.uniform(self.r1, 1/self.r1)

            h = int(round(math.sqrt(target_area * aspect_ratio)))
            w = int(round(math.sqrt(target_area / aspect_ratio)))

            if w < img.size()[2] and h < img.size()[1]:
                x1 = random.randint(0, img.size()[1] - h)
                y1 = random.randint(0, img.size()[2] - w)
                if img.size()[0] == 3:
                    img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                    img_pcb[1, x1:x1+h, y1:y1+w] = self.mean[1]
                    img_pcb[2, x1:x1+h, y1:y1+w] = self.mean[2]
                else:
                    img_pcb[0, x1:x1+h, y1:y1+w] = self.mean[0]
                       
                                      
                             
                         

                
                pcb_ph=ph//pcbnum
                img_pcb[:,0:pcb_ph,:] = img[:,0:pcb_ph,:] 
                img_pcb[:,5*pcb_ph:ph,:] = img[:,5*pcb_ph:ph,:]

                return img_pcb
            
            

        return img

class ChannelRandomErasing(object):
    """ Randomly selects a rectangle region in an image and erases its pixels.
        'Random Erasing Data Augmentation' by Zhong et al.
        See https://arxiv.org/pdf/1708.04896.pdf
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, probability = 0.5, sl = 0.02, sh = 0.4, r1 = 0.3, mean=[0.4914, 0.4822, 0.4465]):
        
        self.probability = probability
        self.mean = mean
        self.sl = sl
        self.sh = sh
        self.r1 = r1
       
    def __call__(self, img):

        if random.uniform(0, 1) > self.probability:
            return img

        for attempt in range(100):
            area = img.size()[1] * img.size()[2]
       
            target_area = random.uniform(self.sl, self.sh) * area
            aspect_ratio = random.uniform(self.r1, 1/self.r1)

            h = int(round(math.sqrt(target_area * aspect_ratio)))
            w = int(round(math.sqrt(target_area / aspect_ratio)))

            if w < img.size()[2] and h < img.size()[1]:
                x1 = random.randint(0, img.size()[1] - h)
                y1 = random.randint(0, img.size()[2] - w)
                if img.size()[0] == 3:
                    img[0, x1:x1+h, y1:y1+w] = self.mean[0]
                    img[1, x1:x1+h, y1:y1+w] = self.mean[1]
                    img[2, x1:x1+h, y1:y1+w] = self.mean[2]
                else:
                    img[0, x1:x1+h, y1:y1+w] = self.mean[0]
                return img

        return img