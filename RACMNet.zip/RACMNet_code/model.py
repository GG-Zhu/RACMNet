﻿import torch
import torch.nn as nn
from torch.nn import init
from resnet import resnet50, resnet18

import torch.nn.functional as F



class PrototypeGuidedContextualMiningModule(nn.Module):
    """Prototype-Guided Contextual Mining Module (PGCM).

    PGCM retrieves context prototypes and uses the reliability mask from
    RRCM to emphasize complementary cross-modality cues.
    """
    def __init__(self, in_channels=1024, mem_dim=128, num_tokens=128, comp_alpha=0.5):
        super(PrototypeGuidedContextualMiningModule, self).__init__()

        self.in_channels = in_channels
        self.mem_dim = mem_dim
        self.num_tokens = num_tokens
        self.comp_alpha = comp_alpha

        hidden_channels = max(in_channels // 4, 64)

                                              
        self.ambiguity_feat = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),

            nn.Conv2d(hidden_channels, mem_dim, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mem_dim),
            nn.ReLU(inplace=True)
        )

                                         
        self.ambiguity_score = nn.Sequential(
            nn.Conv2d(mem_dim, 1, kernel_size=1),
            nn.Sigmoid()
        )

        self.memory_bank = nn.Parameter(torch.randn(num_tokens, mem_dim) * 0.02)

        self.context_bank = nn.Parameter(torch.randn(num_tokens, in_channels) * 0.02)

                           
        self.fuse = nn.Sequential(
            nn.Conv2d(in_channels * 2, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),

            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size=3,
                padding=1,
                groups=in_channels,
                bias=False
            ),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),

            nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels)
        )

        self.gamma = nn.Parameter(torch.zeros(1))

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, s_mask=None):
        B, C, H, W = x.size()

                                               
        ambiguity_feat = self.ambiguity_feat(x)

                                              
        ambiguity_map = self.ambiguity_score(ambiguity_feat)

                                         
        ambiguity_flat = ambiguity_feat.permute(0, 2, 3, 1).contiguous().view(B, H * W, self.mem_dim)

                                            
        ambiguity_norm = F.normalize(ambiguity_flat, dim=-1)
        m_norm = F.normalize(self.memory_bank, dim=-1)

                    
        sim = torch.matmul(ambiguity_norm, m_norm.t())

        attn = F.softmax(sim * 10.0, dim=-1)

                                            
                    
        context = torch.matmul(attn, self.context_bank)

                      
        context = context.view(B, H, W, C).permute(0, 3, 1, 2).contiguous()

                                           
        if s_mask is not None:
            if s_mask.shape[-2:] != (H, W):
                s_mask = F.interpolate(s_mask, size=(H, W), mode='bilinear', align_corners=False)

            s_mask_detach = s_mask.detach()

            comp_gate = ambiguity_map * (1.0 + self.comp_alpha * (1.0 - s_mask_detach))
        else:
            comp_gate = ambiguity_map

                                       
        context = context * comp_gate

                                                             
        delta = self.fuse(torch.cat([x, context], dim=1))

                              
        out = x + self.gamma * delta

        return out, ambiguity_map, comp_gate



class ReliabilityRoutedCueMiningModule(nn.Module):

    def __init__(self, in_channels):
        super(ReliabilityRoutedCueMiningModule, self).__init__()
        self.in_channels = in_channels
        inter_channels = in_channels // 16

        self.saliency_conv = nn.Sequential(
            nn.Conv2d(in_channels, inter_channels, kernel_size=1),
            nn.BatchNorm2d(inter_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, 1, kernel_size=1),
            nn.Sigmoid()
        )

        self.complementary_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1, groups=in_channels),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels)
        )

        self.gamma = nn.Parameter(torch.zeros(1))

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
        nn.init.constant_(self.saliency_conv[-2].weight, 0)
        nn.init.constant_(self.saliency_conv[-2].bias, 0)

    def forward(self, x):
        s_mask = self.saliency_conv(x)
        
        x_pure = x * (1 + s_mask)

        reverse_mask = 1 - s_mask
        x_comp = self.complementary_conv(x) * reverse_mask
        
        out = x_pure + x_comp
        final_out = x + self.gamma * out
        
        return final_out, s_mask

class Normalize(nn.Module):
    def __init__(self, power=2):
        super(Normalize, self).__init__()
        self.power = power

    def forward(self, x):
        norm = x.pow(self.power).sum(1, keepdim=True).pow(1. / self.power)
        out = x.div(norm)
        return out

class Non_local(nn.Module):
    def __init__(self, in_channels, reduc_ratio=2):
        super(Non_local, self).__init__()

        self.in_channels = in_channels
                                                        
        self.inter_channels = in_channels // reduc_ratio

        if self.inter_channels == 0:
            self.inter_channels = 1

        self.g = nn.Sequential(
            nn.Conv2d(in_channels=self.in_channels, out_channels=self.inter_channels, kernel_size=1, stride=1,
                    padding=0),
        )

        self.W = nn.Sequential(
            nn.Conv2d(in_channels=self.inter_channels, out_channels=self.in_channels,
                    kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(self.in_channels),
        )
        nn.init.constant_(self.W[1].weight, 0.0)
        nn.init.constant_(self.W[1].bias, 0.0)



        self.theta = nn.Conv2d(in_channels=self.in_channels, out_channels=self.inter_channels,
                             kernel_size=1, stride=1, padding=0)

        self.phi = nn.Conv2d(in_channels=self.in_channels, out_channels=self.inter_channels,
                           kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        '''
                :param x: (b, c, t, h, w)
                :return:
                '''

        batch_size = x.size(0)
        g_x = self.g(x).view(batch_size, self.inter_channels, -1)
        g_x = g_x.permute(0, 2, 1)

        theta_x = self.theta(x).view(batch_size, self.inter_channels, -1)
        theta_x = theta_x.permute(0, 2, 1)
        phi_x = self.phi(x).view(batch_size, self.inter_channels, -1)
        f = torch.matmul(theta_x, phi_x)
        N = f.size(-1)
                                                          
        f_div_C = f / N

        y = torch.matmul(f_div_C, g_x)
        y = y.permute(0, 2, 1).contiguous()
        y = y.view(batch_size, self.inter_channels, *x.size()[2:])
        W_y = self.W(y)
        z = W_y + x

        return z


                                                                       
def weights_init_kaiming(m):
    classname = m.__class__.__name__
                      
    if classname.find('Conv') != -1:
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
    elif classname.find('Linear') != -1:
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_out')
        init.zeros_(m.bias.data)
    elif classname.find('BatchNorm1d') != -1:
        init.normal_(m.weight.data, 1.0, 0.01)
        init.zeros_(m.bias.data)

def weights_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        init.normal_(m.weight.data, 0, 0.001)
        if m.bias:
            init.zeros_(m.bias.data)



class visible_module(nn.Module):
    def __init__(self, arch='resnet50'):
        super(visible_module, self).__init__()

        model_v = resnet50(pretrained=True,
                           last_conv_stride=1, last_conv_dilation=1)
                                       
        self.visible = model_v

    def forward(self, x):
        x = self.visible.conv1(x)
        x = self.visible.bn1(x)
        x = self.visible.relu(x)
        x = self.visible.maxpool(x)
        return x


class thermal_module(nn.Module):
    def __init__(self, arch='resnet50'):
        super(thermal_module, self).__init__()

        model_t = resnet50(pretrained=True,
                           last_conv_stride=1, last_conv_dilation=1)
                                       
        self.thermal = model_t

    def forward(self, x):
        x = self.thermal.conv1(x)
        x = self.thermal.bn1(x)
        x = self.thermal.relu(x)
        x = self.thermal.maxpool(x)
        return x


class base_resnet(nn.Module):
    def __init__(self, arch='resnet50'):
        super(base_resnet, self).__init__()

        model_base = resnet50(pretrained=True,
                              last_conv_stride=1, last_conv_dilation=1)
                                       
        model_base.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.base = model_base

    def forward(self, x):
        x = self.base.layer1(x)
        x = self.base.layer2(x)
        x = self.base.layer3(x)
        x = self.base.layer4(x)
        return x


class embed_net(nn.Module):
    def __init__(self,  class_num, no_local= 'on', gm_pool = 'on', arch='resnet50'):
        super(embed_net, self).__init__()

        self.thermal_module = thermal_module(arch=arch)
        self.visible_module = visible_module(arch=arch)
        self.base_resnet = base_resnet(arch=arch)
        self.non_local = no_local

        self.rrcm = ReliabilityRoutedCueMiningModule(1024)

        self.pgcm = PrototypeGuidedContextualMiningModule(
            in_channels=1024,
            mem_dim=128,
            num_tokens=128,
            comp_alpha=0.5
        )

        if self.non_local =='on':
            layers=[3, 4, 6, 3]
            non_layers=[0,2,3,0]
            self.NL_1 = nn.ModuleList(
                [Non_local(256) for i in range(non_layers[0])])
            self.NL_1_idx = sorted([layers[0] - (i + 1) for i in range(non_layers[0])])
            self.NL_2 = nn.ModuleList(
                [Non_local(512) for i in range(non_layers[1])])
            self.NL_2_idx = sorted([layers[1] - (i + 1) for i in range(non_layers[1])])
            self.NL_3 = nn.ModuleList(
                [Non_local(1024) for i in range(non_layers[2])])
            self.NL_3_idx = sorted([layers[2] - (i + 1) for i in range(non_layers[2])])
            self.NL_4 = nn.ModuleList(
                [Non_local(2048) for i in range(non_layers[3])])
            self.NL_4_idx = sorted([layers[3] - (i + 1) for i in range(non_layers[3])])


        pool_dim = 2048
        self.l2norm = Normalize(2)
        self.bottleneck = nn.BatchNorm1d(pool_dim)
        self.bottleneck.bias.requires_grad_(False)            

        self.classifier = nn.Linear(pool_dim, class_num, bias=False)

        self.bottleneck.apply(weights_init_kaiming)
        self.classifier.apply(weights_init_classifier)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.gm_pool = gm_pool


    def forward(self, x1, x2, modal=0):
        if modal == 0:
            x1 = self.visible_module(x1)
            x2 = self.thermal_module(x2)
            x = torch.cat((x1, x2), 0)
            
            
        elif modal == 1:
            x = self.visible_module(x1)

        elif modal == 2:
            x = self.thermal_module(x2)


        if self.non_local == 'on':
            NL1_counter = 0
            if len(self.NL_1_idx) == 0: self.NL_1_idx = [-1]
            for i in range(len(self.base_resnet.base.layer1)):
                x = self.base_resnet.base.layer1[i](x)
                if i == self.NL_1_idx[NL1_counter]:
                    x = self.NL_1[NL1_counter](x)
                    NL1_counter += 1
                     
            NL2_counter = 0
            if len(self.NL_2_idx) == 0: self.NL_2_idx = [-1]
            for i in range(len(self.base_resnet.base.layer2)):
                x = self.base_resnet.base.layer2[i](x)
                if i == self.NL_2_idx[NL2_counter]:
                    x = self.NL_2[NL2_counter](x)
                    NL2_counter += 1
                     
            NL3_counter = 0
            if len(self.NL_3_idx) == 0: self.NL_3_idx = [-1]
            for i in range(len(self.base_resnet.base.layer3)):
                x = self.base_resnet.base.layer3[i](x)
                if i == self.NL_3_idx[NL3_counter]:
                    x = self.NL_3[NL3_counter](x)
                    NL3_counter += 1

            x, s_mask = self.rrcm(x)
            x = self.pgcm(x, s_mask)
            
                     
            NL4_counter = 0
            if len(self.NL_4_idx) == 0: self.NL_4_idx = [-1]
            for i in range(len(self.base_resnet.base.layer4)):
                x = self.base_resnet.base.layer4[i](x)
                if i == self.NL_4_idx[NL4_counter]:
                    x = self.NL_4[NL4_counter](x)
                    NL4_counter += 1
        else:
            x = self.base_resnet(x)

        if self.gm_pool == 'on':
            b, c, h, w = x.shape
            x_pool = (torch.mean(x.view(b, c, -1)**3.0, dim=-1) + 1e-12)**(1/3.0)
        else:
            x_pool = self.avgpool(x).view(x.size(0), x.size(1))

        
        feat = self.bottleneck(x_pool)

        if self.training:
            return x_pool, self.classifier(feat), s_mask
        else:
            return self.l2norm(x_pool), self.l2norm(feat)

   

